export default function Button(props: {
    title?: string;
    onClick: () => void;
}): import("react/jsx-runtime").JSX.Element;
